

<?php $__env->startSection('content'); ?>
   <div class="mycart">
       <p class="mycart-title">My Cart</p>
        <div class="mycart-gallery">
            <?php $__empty_1 = true; $__currentLoopData = $user_cart->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="mycart-gallery-item">
                    <div class="mycart-gallery-item-left">
                        <img src="<?php echo e(url('storage/images/products/'. $product->image_path)); ?>" alt="">
                    </div>
                    <div class="mycart-gallery-item-right">
                        <div class="mycart-gallery-item-right-product">
                            <p class="mycart-gallery-item-right-product-name"><?php echo e($product->name); ?></p>
                            <p class="mycart-gallery-item-right-product-value">IDR <?php echo e(number_format($product->price)); ?></p>
                        </div>
                        <p  class="mycart-gallery-item-right-quantity"><?php echo e($product->pivot->quantity); ?> pcs</p>
                        <p  class="mycart-gallery-item-right-subtotal">IDR <?php echo e(number_format($product->pivot->quantity * $product->price)); ?></p>

                        <div class="mycart-gallery-item-right-button">
                            <button class="mycart-gallery-item-right-button-edit"><a href="/cart/edit/<?php echo e($product->id); ?>">Edit</a></button> 

                            <form action="/cart/delete/<?php echo e($product->id); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field("delete"); ?>

                                <button type = "submit" class="mycart-gallery-item-right-button-del">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h2>The cart is empty</h2>
            <?php endif; ?>
        </div>

        <strong>Total Price:</strong>
        <div class="mycart-price">
            <p class="mycart-price-val">IDR <?php echo e(number_format($total_price)); ?></p>

            <form action="/cart/checkout/<?php echo e($user_cart->id); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" id="total_price" name="total_price" value=<?php echo e($total_price); ?>>
                <button>Checkout(<?php echo e($user_cart->products->sum('pivot.quantity')); ?>)</button>
            </form>
        </div>
   </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/cart.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DYID\resources\views/carts/cart.blade.php ENDPATH**/ ?>