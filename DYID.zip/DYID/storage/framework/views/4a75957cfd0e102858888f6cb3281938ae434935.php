

<?php $__env->startSection('content'); ?>
<div class="insert">
    <div class="insert-form">
        <p class="insert-form-name">Insert New Category</p>
        <form action="/category/insert" method="POST">
            <?php echo csrf_field(); ?>

            <input type="text" name="name" id="" placeholder="Category name">
            <input type="submit" value="add">
        </form>


        <div class="insert-form-error">
            <?php if($errors->any()): ?>
                <div class="insert-form-error-loop">
                    
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p><?php echo e($error); ?></p>
                        <br> 
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/insert_category.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\DYID\resources\views/categories/insert_category.blade.php ENDPATH**/ ?>