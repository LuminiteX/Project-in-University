

<?php $__env->startSection('content'); ?>
<div class="insert_product">
    <div class="insert_product-form">
        <p>Insert New Product</p>
        <form action="">
            <input type="text" name="" id="" placeholder="Product Name">
            <textarea name="" id="" cols="30" rows="10" placeholder="Product Description"></textarea>
            <input type="number" name="" id="" placeholder="Price">

            <label for="product_category">Product Category</label>
            <select name="product_category", id="product_category">
                <option value="">Choose One</option>
                <option value="Television">Television</option>
                <option value="Smartphone">Smartphone</option>
            </select>

            <label for="product_img">Product Image</label>
            <input type="file" name="product_category" id="product_img" accept=".jpg"/>
            
            <input type="submit" value="Add">
        </form>
    </div>
    
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/insert_new_product.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\DYID\resources\views/products/insert_product.blade.php ENDPATH**/ ?>