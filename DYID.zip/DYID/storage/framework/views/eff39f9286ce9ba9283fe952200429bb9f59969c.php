


<?php $__env->startSection('content'); ?>
<div class="panel-group" id="accordion">
    <div class="panel panel-default">
      <div class="panel-heading">
        <button class="panel-heading-accordion">2021-03-25 09:16:25</button>
        <div class="panel-heading-accordion-description">
            <div class="table">
                <div class="image">
                    <img src="<?php echo e(asset('/storage/iphonex.png')); ?>" alt="">
                </div>
                <div class="desc">
                    Iphonec XR  
                    <sup>
                      IDR 11.000.000  
                    </sup>
                    <div class="peace">
                        X2pcs
                    </div>
                </div>
                <div class="price">
                    IDR 11.000.000
                </div>
            </div>
            <div class="totalprice">
                <sub>
                    total price IDR 11.000.000
                </sub>    
            </div>
        </div>
      </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo e(URL::asset('js/slider.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset("css/history.css")); ?>">
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\DYID\resources\views/history.blade.php ENDPATH**/ ?>