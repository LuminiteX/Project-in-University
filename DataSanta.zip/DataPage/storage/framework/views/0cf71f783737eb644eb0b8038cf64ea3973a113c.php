

<?php $__env->startSection('content'); ?>
    <h1>
        Edit Category
    </h1>
    
    <p><a href="/categories">Show all category &rarr;</a></p>

    
    <form action="/categories/<?php echo e($data->id); ?>" method="POST">
        
        <?php echo csrf_field(); ?>
        
        <?php echo method_field("PUT"); ?>

        <input type="text" name="name" value="<?php echo e($data->name); ?>">
        <br>
        <br>
        <button type="submit">Update</button>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\BINUS\Datapage\DataPage\resources\views/categories/edit.blade.php ENDPATH**/ ?>