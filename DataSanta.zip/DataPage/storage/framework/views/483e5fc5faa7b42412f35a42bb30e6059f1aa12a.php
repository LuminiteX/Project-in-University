

<?php $__env->startSection('content'); ?>
    <div class="container py-4">
        <br>
        <div class="d-flex justify-content-center">
            <h2>Latest Articles</h2>
        </div>
        <hr>
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-sm-4 d-flex align-items-stretch">
                    <div class="card my-3 w-100 rounded-lg">
            
                        <div class="card-body">
                            <p class="card-text"><?php echo e(date('j F, Y', strtotime($post->created_at))); ?></p>
                            <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="stretched-link"><h5 class="card-title"><b><?php echo e($post->title); ?></b></h5></a>
                            <p class="card-text">By <?php echo e($post->user->name); ?></p>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h5>There are no articles!</h5>
            <?php endif; ?>
        </div>
    </div>
    <div class="d-flex justify-content-center">
        <?php echo e($posts->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DataPage\resources\views/posts/latest.blade.php ENDPATH**/ ?>