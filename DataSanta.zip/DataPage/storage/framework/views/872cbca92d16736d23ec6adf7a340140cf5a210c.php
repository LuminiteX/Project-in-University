

<?php $__env->startSection('content'); ?>

<div
    class="container-fluid bg-primary"
    style="s
        min-height: 300px;
        background-image: url('<?php echo e(asset('storage/banner_img.svg')); ?>');
        background-repeat: no-repeat;
        background-position: center;
    "
>
    <div class="container h-100 py-5">
        <div class="row justify-content-center">
            <div class="col-7">
                <h1 class="text-center text-white">Welcome to Data Santa. To satisfy all your research needs.</h1>
            </div>
        </div>
        <div class="row justify-content-center pt-3">
            <a class="btn btn-info btn-lg" href="<?php echo e(route('latest')); ?>" role="button">View our articles</a>
        </div>
    </div>
</div>

<div class="container">
    <br>
    <div class="d-flex justify-content-center">
        <h2>Published Articles</h2>
    </div>
    <hr>
    <div class="row">
        <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="col-sm-4 d-flex align-items-stretch">
                <div class="card my-3 rounded-lg w-100">
                    <div class="card-body">
                        <p class="card-text"><?php echo e(date('j F, Y', strtotime($post->created_at))); ?></p>
                        <a href="<?php echo e(route('posts.show', $post->id)); ?>" class="stretched-link"><h4 class="card-title"><b><?php echo e($post->title); ?></b></h4></a>
                        <p class="card-text">By <?php echo e($post->user->name); ?></p>
                    </div>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <h5>There are no articles!</h5>
        <?php endif; ?>
    </div>
    <br>
    <div class="d-flex justify-content-center">
        <a href="<?php echo e(route('latest')); ?>" class="btn btn-info btn-lg">See all articles ></a>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DataPage\resources\views/home.blade.php ENDPATH**/ ?>