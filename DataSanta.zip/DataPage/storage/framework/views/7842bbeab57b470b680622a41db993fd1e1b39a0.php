

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <br>
        <div class="container py-4">
            <div class="d-flex justify-content-center">
                <h2>Categories</h2>
            </div>
            <hr>
            <div class="row">
                <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-sm-4 d-flex align-items-stretch">
                        <div class="card my-3 text-center bg-primary border-0 w-100 rounded-lg">
                
                            <div class="card-body">
                                <a href="/category/<?php echo e($category->id); ?>" class="stretched-link"><h4 class="card-title"><b><?php echo e($category->name); ?></b></h4></a>
                                <p class="card-text text-white"><?php echo e($post_counts[$key]); ?> Posts</p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h5>There is no category!</h5>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="d-flex justify-content-center">
        <?php echo e($categories->links()); ?>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DataPage\resources\views/categories/all.blade.php ENDPATH**/ ?>