

<?php $__env->startSection('content'); ?>
<h1>Category List</h1>



<p><a href="categories/create">Add new category &rarr;</a></p>

    <table>
        <tr>
            <th>
                ID
            </th>
            <th>
                Name
            </th>
            <th>
                Operation
            </th>
        </tr>
        <?php $__empty_1 = true; $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <?php echo e($category->id); ?>

                </td>
                <td>
                    <?php echo e($category->name); ?>

                </td>
                <td>
                    
                    <a href="categories/<?php echo e($category->id); ?>/edit">Edit</a>

                    
                    <form action="/categories/<?php echo e($category->id); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('delete'); ?>

                        <button>Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p>There is no category!</p>
        <?php endif; ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Sems 5\Kerkel\Data Santa\resources\views/categories/index.blade.php ENDPATH**/ ?>