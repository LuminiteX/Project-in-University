
<?php $__env->startSection('content'); ?>

<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="card">
        <div class="card-body">
        <h4 class="card-title"><?php echo e($item->title); ?></h4>
        <p class="card-text"><?php echo e($item->content); ?></p>
        <p class="card-text"><b><?php echo e($item->category->name); ?></b></p>
        <a href="/posts/category_update/<?php echo e($item->id); ?>" class="btn btn-warning">Update</a>
        </div>
    </div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <h1>
        Empty
    </h1>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DataPage\resources\views/posts/update_category.blade.php ENDPATH**/ ?>