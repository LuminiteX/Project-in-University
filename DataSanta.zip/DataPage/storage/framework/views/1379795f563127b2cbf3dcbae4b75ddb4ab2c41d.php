<!DOCTYPE html>
<html lang="en">
 <head>
  <title>Insert Form Data Into Database using Laravel </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
 </head>
 <body>

  <div class="container">
   <h2 class="text-center">Insert Form Data Into Database using Laravel</h2>
   <form action="/article" method="post" enctype='multipart/form-data'>
    <?php echo csrf_field(); ?>
    <div class="form-group">
     <label for="title">Title:</label>
     <input type="text" class="form-control" id="title" placeholder="Enter Title" name="title">
   </div>

   <div class="form-group">
    <label for="link">Tableau link:</label>
    <input type="text" class="form-control" id="link" placeholder="Enter Link" name="link">
  </div>

    <div class="form-group">
        <label for="content">article content:</label>
        <textarea class="form-control" rows="5" id="content" name = "content"></textarea>
    </div>

    <div class="form-group">
    <label for="country">Category:</label>
    <select name = "category" id = "category" class="form-control" >
    <?php $__currentLoopData = $category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                <option value="<?php echo e($Category->id); ?>">  
                    <?php echo e($Category->name); ?>  
                </option> 
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
    </select>
    </div>

    <div class="form-group row">
        <label for="file" class="col-md-4 col-form-label text-md-right">Select a file to upload</label>
        <div class="col-md-6">
            <input id="file" type="file" class="form-control <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="file" value="<?php echo e(old('file')); ?>">
            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <button type="submit" class="btn btn-default">Submit</button>
    </form>
</div>

</body>
</html><?php /**PATH D:\Binus\Sems 5\Kerkel\DataPage\resources\views/Article.blade.php ENDPATH**/ ?>