

<?php $__env->startSection('content'); ?>
    <h1>Defo Content</h1>
    <h1> yoooooo </h1>

    <iframe width="560" height="315" src="https://www.youtube.com/embed/xvFZjo5PgG0?autoplay=1" title="YouTube video player" frameborder="0" allowfullscreen></iframe>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Binus\Sems 5\Kerkel\Data Santa\resources\views/test.blade.php ENDPATH**/ ?>