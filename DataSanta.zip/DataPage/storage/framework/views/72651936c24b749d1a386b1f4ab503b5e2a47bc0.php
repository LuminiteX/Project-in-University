
<?php $__env->startSection('content'); ?>


<form action="/posts/category_update/<?php echo e($post->id); ?>" Method="POST">
    <?php echo csrf_field(); ?>
    <div class="card">
        <p><?php echo e($post->title); ?></p>
        <p><?php echo e($post->content); ?></p>
        <label for="category">Category:</label>
        <select name = "category" id = "category" class="form-control">
            <option value="<?php echo e($post->category_id); ?>"><?php echo e($post->category->name); ?></option>
            <?php $__currentLoopData = $category_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($category->id != $post->category->id): ?>
                <option value="<?php echo e($category->id); ?>">  
                <?php echo e($category->name); ?>  
                </option>
            <?php endif; ?> 
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
        </select>
        <button type="submit" class="btn btn-warning" style="margin-top: 5%">update data</button>
        </div>
    </div>
</form>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\kevin\Documents\GitHub\DataPage\resources\views/posts/update_article_category.blade.php ENDPATH**/ ?>